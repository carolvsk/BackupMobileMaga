import React, { useState } from 'react';
import { View, TextInput, KeyboardAvoidingView, Platform, StyleSheet, Dimensions } from 'react-native';

const width = Dimensions.get('screen').width;

export default function NumericKeyboard({ placeholderName }) {
    return <>
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : null}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}> 
        <View>
        <TextInput
        style={styles.input}
        placeholder= 'Digite aqui o  código'
        keyboardType="numeric" />
        </View>
   </KeyboardAvoidingView>

    </>
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      },
    input: {
        backgroundColor: '#F3F3F3',
        borderWidth: 0,
        borderRadius: 5,
        shadowColor: '#5F4E4E',
        shadowOpacity: 20,
        shadowRadius: 2, 
        padding: 30
    },
})


