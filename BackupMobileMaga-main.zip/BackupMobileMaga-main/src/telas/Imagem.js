import {Image, Dimensions, StyleSheet} from "react-native";

const width = Dimensions.get('screen').width;

export default function Imagem() {
    return <>
            <Image source={require("../../assets/topo.png")} style={estilos.topo} resizeMode="contain"/>
    </>
}

const estilos = StyleSheet.create({
    topo: {
        width: "100%",
    },
});