import { StyleSheet, Text} from "react-native";

export default function TextoBody() {
    return <>
            <Text style={estilos.nome}>Para confirmar seu número insira-o abaixo </Text>
    </>
}
const estilos = StyleSheet.create({
    nome:{
        color: "#979797",
        fontSize: 16,
        lineHeight: 20,
      //  fontWeight: "bold",
        textAlign: "center",
    },

});