import React from "react";
import { StyleSheet, Dimensions, Text} from "react-native";


const width = Dimensions.get('screen').width;

export default function Titulo() {
    return <>
            <Text style={estilos.titulo}>Um código foi enviado no número fornecido</Text> 
    </>
}

const estilos = StyleSheet.create({
    titulo: {
        width: "100%",
      // position: "absolute",
        textAlign: "center",
        fontSize: 19,
        lineHeight: 26,
        color: "#666666",
        fontWeight: "bold",
        padding: 16,
    },
});