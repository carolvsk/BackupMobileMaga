import React from 'react';
import { StatusBar, View, StyleSheet } from 'react-native';
import NumberPad from './src/telas/NumberPad'
import Imagem from './src/telas/Imagem';
import TextoBody from './src/telas/TextoBody';
import Titulo from './src/telas/Titulo';

export default function App() {
  return (
    <>
      <View style = {estilos.container}>
        <Imagem/>
        <Titulo/>
        <TextoBody/>
        <View style ={{flexDirection: 'row'}}></View>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center"}}>
          <NumberPad/>
        </View>
      </View>
    </>

  );
}

const estilos = StyleSheet.create({
  container: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      padding: 82
  },

});